import json
from datetime import datetime
import os
import boto3
from xcoin_api_client import *
import pprint

def lambda_handler(event, context):


    #! /usr/bin/env python
    # XCoin API-call sample script (for Python 3.X)
    #
    # @author	btckorea
    # @date	2017-04-11
    #
    #
    # First, Build and install pycurl with the following commands::
    # (if necessary, become root)
    #
    # https://pypi.python.org/pypi/pycurl/7.43.0#downloads
    #
    # tar xvfz pycurl-7.43.0.tar.gz
    # cd pycurl-7.43.0
    # python setup.py --libcurl-dll=libcurl.so install
    # python setup.py --with-openssl install
    # python setup.py install

    api_key = os.environ.get("api_key");
    api_secret = os.environ.get("api_secret_key");

    api = XCoinAPI(api_key, api_secret);

    rgParams = {
    	"order_currency" : "BTC",
    	"payment_currency" : "KRW"
    };


    #
    # public api
    #
    # /public/ticker
    # /public/recent_ticker
    # /public/orderbook
    # /public/recent_transactions

    result = api.xcoinApiCall("/public/ticker", rgParams);
    print("status: " + result["status"]);
    print("last: " + result["data"]["closing_price"]);
    print("sell: " + result["data"]["sell_price"]);
    print("buy: " + result["data"]["buy_price"]);

	# Get the current datetime for the file name
	now = str(datetime.today())

	# Export the data to S3
	client = boto3.client('s3')
	response = client.put_object(Bucket='bitdev.xcoin/ticker',
					Body=result,
					Key='rawdata/{}.json'.format(now))
